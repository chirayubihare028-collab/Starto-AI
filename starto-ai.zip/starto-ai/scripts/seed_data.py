"""
Comprehensive Dataset Seeding Script for Starto AI Ecosystem.
Seeds verified realistic Startups, Tier-1 Venture Capital Funds, Angel Investors, and Industry Mentors.
"""
from backend.app.database import SessionLocal, init_db
from backend.app.models.user import User, UserRole
from backend.app.models.profile import Profile, PitchDeck
from backend.app.utils.security import hash_password


USERS_AND_PROFILES = [
    # --- INVESTORS ---
    {
        "full_name": "Elena Rostova",
        "email": "elena@vertexventures.com",
        "role": UserRole.INVESTOR.value,
        "password": "Password123!",
        "company": "Vertex Ventures",
        "tagline": "Early-Stage DeepTech & Enterprise SaaS Syndicate",
        "bio": "General Partner investing in Seed and Series A AI infrastructure, data engineering, and automation tools across North America and Europe.",
        "website": "https://vertexventures.com",
        "location": "San Francisco, CA",
        "industry": "AI/ML",
        "stage": "Seed",
        "ticket_size_min": 500000.0,
        "ticket_size_max": 2000000.0,
        "thesis": "High conviction in generative workflows, foundation model tooling, and enterprise AI orchestration."
    },
    {
        "full_name": "Marcus Vance",
        "email": "marcus@horizoncap.io",
        "role": UserRole.INVESTOR.value,
        "password": "Password123!",
        "company": "Horizon Capital",
        "tagline": "Next-Gen FinTech & Embedded Finance Syndicate",
        "bio": "Founding Partner backing fintech founders solving cross-border liquidity, algorithmic compliance, and treasury automation.",
        "website": "https://horizoncap.io",
        "location": "New York, NY",
        "industry": "FinTech",
        "stage": "Seed",
        "ticket_size_min": 250000.0,
        "ticket_size_max": 1500000.0,
        "thesis": "FinTech infrastructure, decentralized settlements, API-first banking, and B2B payment rails."
    },
    {
        "full_name": "Aria Patel",
        "email": "aria@biospark.vc",
        "role": UserRole.INVESTOR.value,
        "password": "Password123!",
        "company": "BioSpark Ventures",
        "tagline": "Computational Biology & Modern HealthTech Fund",
        "bio": "Investing in data-driven therapeutics, digital health platforms, and AI diagnostics reshaping clinical outcomes.",
        "website": "https://biospark.vc",
        "location": "Boston, MA",
        "industry": "HealthTech",
        "stage": "Series A",
        "ticket_size_min": 1000000.0,
        "ticket_size_max": 4000000.0,
        "thesis": "Digital clinical trials, automated radiology models, preventative healthcare software."
    },
    {
        "full_name": "David Sterling",
        "email": "david@greenfrontier.org",
        "role": UserRole.INVESTOR.value,
        "password": "Password123!",
        "company": "GreenFrontier Capital",
        "tagline": "Decarbonization, CleanTech & Sustainable Grid Fund",
        "bio": "Venture partner focused on circular economy, carbon accounting systems, and grid intelligence software.",
        "website": "https://greenfrontier.org",
        "location": "Austin, TX",
        "industry": "CleanTech",
        "stage": "Seed",
        "ticket_size_min": 300000.0,
        "ticket_size_max": 1500000.0,
        "thesis": "Smart energy grids, enterprise carbon compliance, battery telemetry analytics."
    },

    # --- MENTORS ---
    {
        "full_name": "Dr. Sarah Lin",
        "email": "sarah.lin@stanford-alum.edu",
        "role": UserRole.MENTOR.value,
        "password": "Password123!",
        "company": "Former VP of AI at Stripe",
        "tagline": "Scaling Machine Learning & Production Vector Systems",
        "bio": "12+ years building and deploying scalable AI systems. Mentoring technical founders on MLOps, hiring top researchers, and product-market fit.",
        "website": "https://sarahlin.ai",
        "location": "Palo Alto, CA",
        "industry": "AI/ML",
        "stage": "Seed",
        "ticket_size_min": 0.0,
        "ticket_size_max": 0.0,
        "thesis": "Expert in Transformer architectures, prompt-to-production pipelines, and technical founder leadership."
    },
    {
        "full_name": "James O'Connor",
        "email": "james@growthplaybook.co",
        "role": UserRole.MENTOR.value,
        "password": "Password123!",
        "company": "Ex-CRO at Brex",
        "tagline": "B2B SaaS Go-To-Market & Enterprise Sales Architect",
        "bio": "Helped scale ARR from $1M to $80M+. Advising early-stage founders on pricing, sales engineering, and outbound pipelines.",
        "website": "https://growthplaybook.co",
        "location": "San Francisco, CA",
        "industry": "FinTech",
        "stage": "Seed",
        "ticket_size_min": 0.0,
        "ticket_size_max": 0.0,
        "thesis": "Inbound/outbound sales engines, enterprise procurement navigation, SDR playbooks."
    },
    {
        "full_name": "Maya Al-Mansoor",
        "email": "maya@venturelegal.io",
        "role": UserRole.MENTOR.value,
        "password": "Password123!",
        "company": "Partner, Global Tech Counsel",
        "tagline": "Fundraising Governance, Term Sheets & SAFE Negotiations",
        "bio": "Advising founders through hundreds of venture rounds, cap table structuring, priced rounds, and IP protection.",
        "website": "https://venturelegal.io",
        "location": "London, UK",
        "industry": "SaaS",
        "stage": "Pre-Seed",
        "ticket_size_min": 0.0,
        "ticket_size_max": 0.0,
        "thesis": "Cap table clean-ups, investor rights negotiation, international incorporation."
    },

    # --- STARTUPS ---
    {
        "full_name": "Alex Mercer",
        "email": "alex@synthwave.ai",
        "role": UserRole.STARTUP.value,
        "password": "Password123!",
        "company": "Synthwave AI",
        "tagline": "Autonomous Multimodal Synthetic Data Engine",
        "bio": "Synthwave creates high-fidelity photorealistic and tabular synthetic data for training autonomous perception models without privacy violations.",
        "website": "https://synthwave.ai",
        "location": "Seattle, WA",
        "industry": "AI/ML",
        "stage": "Seed",
        "ticket_size_min": 500000.0,
        "ticket_size_max": 1500000.0,
        "traction_arr": 420000.0,
        "thesis": "Enterprise ML teams face acute data scarcity; our diffusion generators provide instant synthetic batches.",
        "deck": {
            "title": "Synthwave AI Seed Round 2026",
            "problem": "AI teams spend 80% of budgets on data collection, human labeling, and privacy compliance.",
            "solution": "Generative synthetic simulation engines providing on-demand synthetic multimodal benchmarks with zero privacy liability.",
            "market_size_tam": "$18B Synthetic Data & Automated Labeling Market",
            "business_model": "Usage-based API and enterprise data generation pipelines at $50k-$200k ACV.",
            "target_raise": 1500000.0
        }
    },
    {
        "full_name": "Sofia Reyes",
        "email": "sofia@novapay.io",
        "role": UserRole.STARTUP.value,
        "password": "Password123!",
        "company": "NovaPay",
        "tagline": "Instant Cross-Border Settlement Rails for Freelancers",
        "bio": "Empowering 70M+ distributed global knowledge workers with instant multi-currency accounts and fee-less real-time payouts.",
        "website": "https://novapay.io",
        "location": "Miami, FL",
        "industry": "FinTech",
        "stage": "Seed",
        "ticket_size_min": 300000.0,
        "ticket_size_max": 1200000.0,
        "traction_arr": 680000.0,
        "thesis": "Legacy remittance rails extract 4-7% in friction; NovaPay reduces fees to under 0.4% with sub-second clearing.",
        "deck": {
            "title": "NovaPay Series Seed",
            "problem": "Global independent contractors lose up to 7% in currency conversions and wait 5 days for payouts.",
            "solution": "Direct integration with global instant payment rails (FedNow, Pix, UPI, SEPA Instant) via a single unified API.",
            "market_size_tam": "$32B Global Gig Economy Payout Market",
            "business_model": "0.3% interchange take-rate and treasury yield monetization.",
            "target_raise": 1200000.0
        }
    },
    {
        "full_name": "Dr. Ethan Cole",
        "email": "ethan@pulsarhealth.com",
        "role": UserRole.STARTUP.value,
        "password": "Password123!",
        "company": "Pulsar Health",
        "tagline": "Continuous Remote Oncology Biomarker Tracking",
        "bio": "Non-invasive wearable biosensors paired with real-time ML anomaly detection for early cancer recurrence monitoring.",
        "website": "https://pulsarhealth.com",
        "location": "San Diego, CA",
        "industry": "HealthTech",
        "stage": "Seed",
        "ticket_size_min": 500000.0,
        "ticket_size_max": 2000000.0,
        "traction_arr": 150000.0,
        "thesis": "Clinicians need proactive warning signals before clinical relapses occur in outpatient oncology care.",
        "deck": {
            "title": "Pulsar Health Seed Deck",
            "problem": "Post-remission oncology patients are checked only once every 3-6 months, missing critical recurrence windows.",
            "solution": "Medical-grade wearable transdermal sensor streaming continuous biomarker data to an FDA-cleared ML triage portal.",
            "market_size_tam": "$24B Remote Patient Monitoring & Oncology Software",
            "business_model": "B2B SaaS per active monitored patient + remote physiological monitoring (RPM) reimbursement codes.",
            "target_raise": 1800000.0
        }
    }
]


def seed_dataset():
    init_db()
    db = SessionLocal()
    try:
        print("Seeding Starto AI realistic ecosystem dataset...")
        for item in USERS_AND_PROFILES:
            user = db.query(User).filter(User.email == item["email"]).first()
            if not user:
                user = User(
                    email=item["email"],
                    hashed_password=hash_password(item["password"]),
                    full_name=item["full_name"],
                    role=item["role"],
                    is_active=True
                )
                db.add(user)
                db.commit()
                db.refresh(user)
                print(f"Created user: {user.email} ({user.role})")

            profile = db.query(Profile).filter(Profile.user_id == user.id).first()
            if not profile:
                profile = Profile(
                    user_id=user.id,
                    role=user.role,
                    company_or_firm_name=item["company"],
                    tagline=item["tagline"],
                    bio=item["bio"],
                    website=item["website"],
                    location=item["location"],
                    industry=item["industry"],
                    stage=item["stage"],
                    ticket_size_min=item.get("ticket_size_min", 0.0),
                    ticket_size_max=item.get("ticket_size_max", 0.0),
                    traction_arr=item.get("traction_arr", 0.0),
                    skills_or_thesis=item.get("thesis", "")
                )
                db.add(profile)
                db.commit()
                print(f"  -> Profile seeded for: {item['company']}")

            if "deck" in item:
                d = item["deck"]
                existing_deck = db.query(PitchDeck).filter(PitchDeck.user_id == user.id, PitchDeck.title == d["title"]).first()
                if not existing_deck:
                    deck = PitchDeck(
                        user_id=user.id,
                        title=d["title"],
                        filename=f"{d['title'].lower().replace(' ', '_')}.pdf",
                        problem=d["problem"],
                        solution=d["solution"],
                        market_size_tam=d["market_size_tam"],
                        business_model=d["business_model"],
                        target_raise=d["target_raise"],
                        deck_status="Parsed & Ready"
                    )
                    db.add(deck)
                    db.commit()
                    print(f"  -> Pitch Deck seeded: {deck.title}")

        print("Seeding completed successfully!")
    finally:
        db.close()


if __name__ == "__main__":
    seed_dataset()
