/**
 * Starto AI Frontend Application
 * Fully interactive Next-Gen SaaS Ecosystem interface
 */

const app = {
  state: {
    token: localStorage.getItem('starto_token') || null,
    user: JSON.parse(localStorage.getItem('starto_user') || 'null'),
    currentView: 'landing', // 'landing' | 'dashboard'
    dashboardTab: 'overview', // 'overview' | 'profile' | 'pitchdeck' | 'investors' | 'mentors' | 'saved' | 'interactions'
    systemStatus: null,
    profileData: null,
    pitchDecks: [],
    investorMatches: [],
    mentorMatches: [],
    interactions: [],
    filterIndustry: 'ALL',
    filterMinScore: 0,
    searchQuery: ''
  },

  init() {
    this.checkHealth();
    if (this.state.token && this.state.user) {
      this.renderDashboard();
    } else {
      this.renderLanding();
    }
  },

  getAuthHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.state.token}`
    };
  },

  async checkHealth() {
    try {
      const res = await fetch('/health');
      if (res.ok) {
        this.state.systemStatus = await res.json();
      }
    } catch (e) {
      console.warn("Backend health check:", e);
    }
  },

  // -------------------------------------------------------------
  // LANDING PAGE VIEW
  // -------------------------------------------------------------
  renderLanding() {
    this.state.currentView = 'landing';
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <!-- Hero Section -->
      <section class="hero-section">
        <div class="hero-glow"></div>
        <div class="hero-container">
          <div class="hero-pill-tag">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
            </svg>
            Next-Generation Neural Matching Ecosystem
          </div>
          <h1 class="hero-title">Where Startups Meet<br>the Right Opportunities.</h1>
          <p class="hero-subtitle">
            Starto AI uses intelligent multi-factor matching to connect startups with investors and mentors based on industry, stage, funding needs, expertise, and explainable neural compatibility.
          </p>
          <div class="hero-cta-group">
            <button class="btn btn-white btn-lg btn-pill" id="hero-primary-cta" onclick="app.showAuthModal('register')">
              Find Your Matches
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="5" y1="12" x2="19" y2="12"></line>
                <polyline points="12 5 19 12 12 19"></polyline>
              </svg>
            </button>
            <a href="#how-it-works" class="btn btn-outline-white btn-lg btn-pill">Explore How It Works</a>
            <button class="btn btn-outline-white btn-lg btn-pill" style="border-color: rgba(255,255,255,0.4);" onclick="app.demoQuickLogin('founder')">
              ⚡ Demo Founder
            </button>
            <button class="btn btn-outline-white btn-lg btn-pill" style="border-color: rgba(255,255,255,0.4);" onclick="app.demoQuickLogin('investor')">
              ⚡ Demo Investor
            </button>
          </div>

          <!-- Hero Floating Preview Card -->
          <div class="hero-preview-wrapper">
            <div class="hero-preview-card">
              <div class="preview-badge-row">
                <span class="match-score-badge">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                  95% Match
                </span>
                <span style="font-size: 0.8rem; font-weight: 600; color: #64748b;">Seed Stage Round</span>
              </div>
              <h3 class="preview-company-name">Vertex Ventures</h3>
              <p class="preview-meta">AI/ML • Seed • $500K – $2.0M</p>

              <div class="preview-checks">
                <span class="check-pill active">✓ Industry Match (AI/ML)</span>
                <span class="check-pill active">✓ Stage Match (Seed)</span>
                <span class="check-pill active">✓ Ticket Compatible</span>
              </div>

              <div class="preview-why-box">
                <div class="preview-why-title">Why this match?</div>
                <div class="preview-why-desc">
                  Exceptional synergy with Vertex Ventures driven by shared focus on enterprise AI orchestration, generative workflows, and compatible $1.5M funding round size.
                </div>
              </div>

              <div class="preview-footer-link" onclick="app.showAuthModal('register')">
                View Full Neural Breakdown →
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Section 1: One Platform. Three Connections -->
      <section class="section" id="how-it-works">
        <div class="section-container">
          <div class="section-header">
            <span class="section-tag">Ecosystem Alignment</span>
            <h2 class="section-title">One Platform. Three Connections.</h2>
            <p class="section-subtitle">A unified network engineered for high-conviction synergy across the venture lifecycle.</p>
          </div>
          <div class="ecosystem-grid">
            <div class="ecosystem-card" id="for-startups">
              <div class="card-icon-wrapper icon-blue">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
              </div>
              <h3 class="card-title">Startups</h3>
              <p class="card-desc">Find investors and mentors aligned with your vision, stage, and capital requirements.</p>
              <button class="btn btn-secondary full-width" onclick="app.showAuthModal('register', 'STARTUP')">Join as Founder →</button>
            </div>

            <div class="ecosystem-card" id="for-investors">
              <div class="card-icon-wrapper icon-indigo">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
              </div>
              <h3 class="card-title">Investors</h3>
              <p class="card-desc">Discover pre-filtered, thesis-aligned startups with explainable compatibility vectors.</p>
              <button class="btn btn-secondary full-width" onclick="app.showAuthModal('register', 'INVESTOR')">Join as Investor →</button>
            </div>

            <div class="ecosystem-card" id="for-mentors">
              <div class="card-icon-wrapper icon-green">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              </div>
              <h3 class="card-title">Mentors</h3>
              <p class="card-desc">Support founders where your domain expertise and execution playbook matter most.</p>
              <button class="btn btn-secondary full-width" onclick="app.showAuthModal('register', 'MENTOR')">Join as Mentor →</button>
            </div>
          </div>
        </div>
      </section>

      <!-- Section 2: 4-Step Visual Process -->
      <section class="section section-alt">
        <div class="section-container">
          <div class="section-header">
            <span class="section-tag">Intelligent Workflow</span>
            <h2 class="section-title">How Starto AI Matches You</h2>
            <p class="section-subtitle">From raw pitch deck to explainable high-conviction partnerships in four automated steps.</p>
          </div>
          <div class="process-grid">
            <div class="step-card">
              <div class="step-number">01</div>
              <h4 class="step-title">Build Your Profile</h4>
              <p class="step-desc">Specify stage, traction, ticket sizes, market vertical, and geographic requirements.</p>
            </div>
            <div class="step-card">
              <div class="step-number">02</div>
              <h4 class="step-title">Upload Pitch Deck</h4>
              <p class="step-desc">Our neural parser extracts problem, solution, market size, and business model automatically.</p>
            </div>
            <div class="step-card">
              <div class="step-number">03</div>
              <h4 class="step-title">AI Finds Matches</h4>
              <p class="step-desc">FAISS vector search combined with multi-factor Learning-to-Rank retrieves top candidates.</p>
            </div>
            <div class="step-card">
              <div class="step-number">04</div>
              <h4 class="step-title">Understand WHY</h4>
              <p class="step-desc">Transparent feature attribution reveals exactly why each recommendation was scored.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- Section 3: Multi-Factor Neural Intelligence -->
      <section class="section" id="technology">
        <div class="section-container">
          <div class="section-header">
            <span class="section-tag">Multi-Dimensional Signals</span>
            <h2 class="section-title">Matching Beyond Keywords</h2>
            <p class="section-subtitle">We look deeper than buzzwords to calculate holistic, multi-factor compatibility.</p>
          </div>
          <div class="ecosystem-grid">
            <div class="ecosystem-card">
              <h3 class="card-title">Semantic Context</h3>
              <p class="card-desc">Sentence Transformers capture deep nuanced meaning across investment theses and pitch narratives.</p>
            </div>
            <div class="ecosystem-card">
              <h3 class="card-title">Capital & Stage Rules</h3>
              <p class="card-desc">Hard constraints enforce ticket compatibility and funding stages so neither party wastes time.</p>
            </div>
            <div class="ecosystem-card">
              <h3 class="card-title">Graph Intelligence</h3>
              <p class="card-desc">Neo4j relationship graph maps co-investor syndicates, shared sectors, and alumni networks.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- Section 4: Explainability UI Section -->
      <section class="section section-alt">
        <div class="section-container">
          <div class="section-header">
            <span class="section-tag">Explainable AI</span>
            <h2 class="section-title">Every Recommendation Comes With a Reason</h2>
            <p class="section-subtitle">No black boxes. Inspect granular feature contributions and conviction drivers.</p>
          </div>
          <div class="explain-card">
            <div class="explain-score-header">
              <div>
                <span style="font-size: 0.85rem; font-weight: 700; color: var(--gray-500); text-transform: uppercase;">Composite Score</span>
                <h3 style="font-size: 1.5rem; font-weight: 800; color: var(--gray-900);">Vertex Ventures (Elena Rostova)</h3>
              </div>
              <div class="score-huge">95%</div>
            </div>

            <div class="breakdown-row">
              <div class="breakdown-label-group">
                <span>Industry Alignment</span>
                <span>95%</span>
              </div>
              <div class="progress-track"><div class="progress-fill" style="width: 95%;"></div></div>
            </div>

            <div class="breakdown-row">
              <div class="breakdown-label-group">
                <span>Stage Compatibility</span>
                <span>95%</span>
              </div>
              <div class="progress-track"><div class="progress-fill" style="width: 95%;"></div></div>
            </div>

            <div class="breakdown-row">
              <div class="breakdown-label-group">
                <span>Ticket Size Fit</span>
                <span>94%</span>
              </div>
              <div class="progress-track"><div class="progress-fill" style="width: 94%;"></div></div>
            </div>

            <div class="breakdown-row">
              <div class="breakdown-label-group">
                <span>Semantic Thesis Similarity</span>
                <span>96%</span>
              </div>
              <div class="progress-track"><div class="progress-fill" style="width: 96%;"></div></div>
            </div>

            <div class="breakdown-row">
              <div class="breakdown-label-group">
                <span>Domain Experience</span>
                <span>86%</span>
              </div>
              <div class="progress-track"><div class="progress-fill" style="width: 86%;"></div></div>
            </div>

            <div class="preview-why-box" style="margin-top: 24px;">
              <div class="preview-why-title">Why this match?</div>
              <div class="preview-why-desc">
                Strong alignment with AI/ML infrastructure, Seed-stage focus, and target check range of $500K–$2M.
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- CTA Banner -->
      <div class="cta-banner">
        <h2 class="cta-banner-title">Your next connection could change everything.</h2>
        <p class="cta-banner-sub">Join hundreds of founders, investors, and operators building high-growth companies.</p>
        <button class="btn btn-white btn-lg btn-pill" onclick="app.showAuthModal('register')">Get Started Today</button>
      </div>

      <!-- Footer -->
      <footer class="footer">
        <div class="footer-container">
          <div class="footer-top">
            <div class="brand">
              <div class="brand-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" stroke-width="2"/><path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2"/><path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2"/></svg>
              </div>
              <span>Starto AI</span>
            </div>
            <div class="footer-links">
              <a href="#how-it-works" class="footer-link">How It Works</a>
              <a href="#for-startups" class="footer-link">Startups</a>
              <a href="#for-investors" class="footer-link">Investors</a>
              <a href="#for-mentors" class="footer-link">Mentors</a>
              <a href="/docs" target="_blank" class="footer-link">API Docs</a>
              <a href="/health" target="_blank" class="footer-link">System Health</a>
            </div>
          </div>
          <div class="footer-bottom">
            <span>© 2026 Starto AI Ecosystem. All rights reserved.</span>
            <span>AI-Powered Startup-Investor-Mentor Matching.</span>
          </div>
        </div>
      </footer>
    `;
  },

  // Demo shortcut login helper
  async demoQuickLogin(role) {
    const creds = role === 'investor' 
      ? { email: 'elena@vertexventures.com', password: 'Password123!' }
      : { email: 'alex@synthwave.ai', password: 'Password123!' };
    
    try {
      const res = await fetch('/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(creds)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Demo login failed');
      this.state.token = data.access_token;
      this.state.user = data.user;
      localStorage.setItem('starto_token', data.access_token);
      localStorage.setItem('starto_user', JSON.stringify(data.user));
      this.showToast(`Logged in as Demo ${data.user.full_name} (${data.user.role})`, 'success');
      this.renderDashboard();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // -------------------------------------------------------------
  // DASHBOARD MAIN VIEW
  // -------------------------------------------------------------
  async renderDashboard(tab = this.state.dashboardTab || 'overview') {
    this.state.currentView = 'dashboard';
    this.state.dashboardTab = tab;
    const main = document.getElementById('main-content');
    const user = this.state.user || { role: 'STARTUP', full_name: 'Founder' };

    main.innerHTML = `
      <div class="dashboard-layout">
        <!-- Sidebar Navigation -->
        <aside class="sidebar">
          <div class="sidebar-header">
            <div class="brand" onclick="app.setTab('overview')" style="cursor: pointer;">
              <div class="brand-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" stroke-width="2"/><path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2"/><path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2"/></svg>
              </div>
              <span>Starto AI</span>
            </div>
          </div>
          <nav class="sidebar-nav">
            <div class="sidebar-item ${tab === 'overview' ? 'active' : ''}" onclick="app.setTab('overview')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
              Dashboard
            </div>
            <div class="sidebar-item ${tab === 'profile' ? 'active' : ''}" onclick="app.setTab('profile')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              My Profile
            </div>
            ${user.role === 'STARTUP' ? `
            <div class="sidebar-item ${tab === 'pitchdeck' ? 'active' : ''}" onclick="app.setTab('pitchdeck')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
              Pitch Deck
            </div>` : ''}
            <div class="sidebar-item ${tab === 'investors' ? 'active' : ''}" onclick="app.setTab('investors')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
              ${user.role === 'INVESTOR' ? 'Startup Matches' : 'Investor Matches'}
            </div>
            <div class="sidebar-item ${tab === 'mentors' ? 'active' : ''}" onclick="app.setTab('mentors')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              Mentor Matches
            </div>
            <div class="sidebar-item ${tab === 'saved' ? 'active' : ''}" onclick="app.setTab('saved')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
              Saved Matches
            </div>
            <div class="sidebar-item ${tab === 'interactions' ? 'active' : ''}" onclick="app.setTab('interactions')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
              Interactions
            </div>
          </nav>
          <div class="sidebar-footer">
            <button class="btn btn-ghost full-width" onclick="app.logout()">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
              Log Out
            </button>
          </div>
        </aside>

        <!-- Main Dashboard Content Area -->
        <section class="dashboard-main">
          <header class="dashboard-topbar">
            <div>
              <span style="font-weight: 700; color: var(--gray-900); font-size: 1.15rem; display: flex; align-items: center; gap: 8px;">
                ${this.getTabTitle(tab)}
              </span>
            </div>
            <div style="display: flex; align-items: center; gap: 16px;">
              <div style="text-align: right;">
                <div style="font-size: 0.9rem; font-weight: 700; color: var(--gray-900);">${user.full_name}</div>
                <div style="font-size: 0.75rem; font-weight: 600; color: var(--primary-600); text-transform: uppercase;">${user.role}</div>
              </div>
              <button class="btn btn-secondary btn-sm" onclick="app.logout()">Exit</button>
            </div>
          </header>

          <div class="dashboard-content" id="dashboard-tab-content">
            <div style="text-align: center; padding: 40px; color: var(--gray-500);">Loading dashboard data...</div>
          </div>
        </section>
      </div>
    `;

    // Load and render tab content
    await this.loadTabContent(tab);
  },

  getTabTitle(tab) {
    const titles = {
      overview: 'Workspace Overview',
      profile: 'Company & Investment Profile',
      pitchdeck: 'Pitch Deck & Neural Parser',
      investors: this.state.user?.role === 'INVESTOR' ? 'Recommended Startup Deal Flow' : 'Recommended Investor Matches',
      mentors: 'Recommended Domain Mentors',
      saved: 'Saved Matches & Bookmarks',
      interactions: 'Active Outreaches & Introductions'
    };
    return titles[tab] || 'Workspace';
  },

  setTab(tab) {
    this.state.dashboardTab = tab;
    this.renderDashboard(tab);
  },

  async loadTabContent(tab) {
    const container = document.getElementById('dashboard-tab-content');
    if (!container) return;

    try {
      if (tab === 'overview') {
        await this.renderOverviewTab(container);
      } else if (tab === 'profile') {
        await this.renderProfileTab(container);
      } else if (tab === 'pitchdeck') {
        await this.renderPitchDeckTab(container);
      } else if (tab === 'investors') {
        await this.renderMatchesTab(container, this.state.user?.role === 'INVESTOR' ? 'STARTUP' : 'INVESTOR');
      } else if (tab === 'mentors') {
        await this.renderMatchesTab(container, 'MENTOR');
      } else if (tab === 'saved') {
        await this.renderSavedTab(container);
      } else if (tab === 'interactions') {
        await this.renderInteractionsTab(container);
      }
    } catch (err) {
      console.error("Tab load error:", err);
      container.innerHTML = `<div class="toast error" style="margin: 20px;">Failed to load data: ${err.message}</div>`;
    }
  },

  // -------------------------------------------------------------
  // TAB: OVERVIEW
  // -------------------------------------------------------------
  async renderOverviewTab(container) {
    // Fetch profile, decks, and match count
    const [profileRes, decksRes, matchesRes] = await Promise.all([
      fetch('/api/v1/profile/me', { headers: this.getAuthHeaders() }),
      fetch('/api/v1/pitch-decks', { headers: this.getAuthHeaders() }),
      fetch('/api/v1/matches', { headers: this.getAuthHeaders() })
    ]);

    const profile = profileRes.ok ? await profileRes.json() : null;
    const decks = decksRes.ok ? await decksRes.json() : [];
    const matches = matchesRes.ok ? await matchesRes.json() : [];

    this.state.profileData = profile;
    this.state.pitchDecks = decks;

    const user = this.state.user;
    const topMatches = matches.slice(0, 3);

    container.innerHTML = `
      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 1.75rem; font-weight: 800; color: var(--gray-900);">
          Welcome back, ${user.full_name}.
        </h2>
        <p style="color: var(--gray-600); font-size: 0.95rem;">
          Here is your real-time ecosystem synergy overview and match telemetry.
        </p>
      </div>

      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-label">Profile Completion</div>
          <div class="stat-val" style="color: var(--primary-600);">${profile?.company_or_firm_name ? '100%' : '65%'}</div>
          <div style="font-size: 0.8rem; color: var(--gray-500); margin-top: 4px;">${profile?.company_or_firm_name || 'Incomplete'}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Pitch Decks</div>
          <div class="stat-val" style="color: var(--success-600);">${decks.length}</div>
          <div style="font-size: 0.8rem; color: var(--gray-500); margin-top: 4px;">${decks.length > 0 ? decks[0].deck_status : 'None uploaded'}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">High-Conviction Matches</div>
          <div class="stat-val">${matches.length}</div>
          <div style="font-size: 0.8rem; color: var(--gray-500); margin-top: 4px;">>80% Neural Compatibility</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Target Industry</div>
          <div class="stat-val" style="font-size: 1.4rem; color: var(--secondary-700);">${profile?.industry || 'AI/ML'}</div>
          <div style="font-size: 0.8rem; color: var(--gray-500); margin-top: 4px;">Stage: ${profile?.stage || 'Seed'}</div>
        </div>
      </div>

      <div style="margin-top: 36px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
          <h3 style="font-size: 1.25rem; font-weight: 700;">Top Recommendations For You</h3>
          <button class="btn btn-secondary btn-sm" onclick="app.setTab('investors')">View All Matches →</button>
        </div>

        ${matches.length === 0 ? `
          <div class="stat-card" style="text-align: center; padding: 40px;">
            <p style="color: var(--gray-500);">No candidate profiles found yet. Complete your profile to trigger neural indexing!</p>
            <button class="btn btn-primary" style="margin-top: 12px;" onclick="app.setTab('profile')">Update Profile</button>
          </div>
        ` : `
          <div class="matches-grid">
            ${topMatches.map(m => this.createMatchCardHtml(m)).join('')}
          </div>
        `}
      </div>
    `;
  },

  // -------------------------------------------------------------
  // TAB: PROFILE MANAGEMENT
  // -------------------------------------------------------------
  async renderProfileTab(container) {
    const res = await fetch('/api/v1/profile/me', { headers: this.getAuthHeaders() });
    const profile = res.ok ? await res.json() : {};
    this.state.profileData = profile;
    const user = this.state.user;

    container.innerHTML = `
      <div style="max-width: 800px; background: var(--white); border: 1px solid var(--gray-200); border-radius: var(--radius-lg); padding: 32px; box-shadow: var(--shadow-sm);">
        <h3 style="font-size: 1.35rem; font-weight: 700; margin-bottom: 8px;">
          ${user.role === 'INVESTOR' ? 'Venture Fund & Thesis Profile' : (user.role === 'MENTOR' ? 'Advisory & Expertise Profile' : 'Startup Company Profile')}
        </h3>
        <p style="color: var(--gray-500); font-size: 0.9rem; margin-bottom: 24px;">
          Configure your organization details, check sizes, and core focus to train the matching algorithm.
        </p>

        <form onsubmit="app.handleProfileSave(event)">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="form-group">
              <label class="form-label">${user.role === 'INVESTOR' ? 'Fund / Syndicate Name' : 'Company Name'}</label>
              <input type="text" class="form-input" id="prof-company" value="${profile.company_or_firm_name || ''}" required placeholder="Acme AI Technologies">
            </div>
            <div class="form-group">
              <label class="form-label">Tagline</label>
              <input type="text" class="form-input" id="prof-tagline" value="${profile.tagline || ''}" placeholder="Autonomous data infrastructure">
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="form-group">
              <label class="form-label">Primary Industry</label>
              <select class="form-select" id="prof-industry">
                ${['AI/ML', 'FinTech', 'HealthTech', 'CleanTech', 'SaaS', 'EdTech', 'Cybersecurity'].map(ind => `
                  <option value="${ind}" ${profile.industry === ind ? 'selected' : ''}>${ind}</option>
                `).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Funding Stage</label>
              <select class="form-select" id="prof-stage">
                ${['Pre-Seed', 'Seed', 'Series A', 'Series B+', 'Growth'].map(stg => `
                  <option value="${stg}" ${profile.stage === stg ? 'selected' : ''}>${stg}</option>
                `).join('')}
              </select>
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px;">
            <div class="form-group">
              <label class="form-label">${user.role === 'INVESTOR' ? 'Min Check Size ($)' : 'Min Target Round ($)'}</label>
              <input type="number" class="form-input" id="prof-ticket-min" value="${profile.ticket_size_min || 250000}" step="50000">
            </div>
            <div class="form-group">
              <label class="form-label">${user.role === 'INVESTOR' ? 'Max Check Size ($)' : 'Max Target Round ($)'}</label>
              <input type="number" class="form-input" id="prof-ticket-max" value="${profile.ticket_size_max || 1500000}" step="50000">
            </div>
            <div class="form-group">
              <label class="form-label">${user.role === 'STARTUP' ? 'ARR Traction ($)' : 'Location / HQ'}</label>
              <input type="text" class="form-input" id="prof-location" value="${profile.location || 'San Francisco, CA'}">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Website</label>
            <input type="url" class="form-input" id="prof-website" value="${profile.website || ''}" placeholder="https://example.com">
          </div>

          <div class="form-group">
            <label class="form-label">${user.role === 'INVESTOR' ? 'Investment Thesis & Focus Areas' : 'Company Overview & Value Proposition'}</label>
            <textarea class="form-input" id="prof-thesis" rows="4" placeholder="Describe your focus, customer segments, and technology advantages...">${profile.skills_or_thesis || ''}</textarea>
          </div>

          <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
            <button type="submit" class="btn btn-primary">Save Profile Changes</button>
          </div>
        </form>
      </div>
    `;
  },

  async handleProfileSave(e) {
    e.preventDefault();
    const payload = {
      company_or_firm_name: document.getElementById('prof-company').value,
      tagline: document.getElementById('prof-tagline').value,
      industry: document.getElementById('prof-industry').value,
      stage: document.getElementById('prof-stage').value,
      ticket_size_min: parseFloat(document.getElementById('prof-ticket-min').value) || 0,
      ticket_size_max: parseFloat(document.getElementById('prof-ticket-max').value) || 0,
      location: document.getElementById('prof-location').value,
      website: document.getElementById('prof-website').value,
      skills_or_thesis: document.getElementById('prof-thesis').value
    };

    try {
      const res = await fetch('/api/v1/profile/me', {
        method: 'PUT',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Failed to update profile');
      this.showToast('Profile updated successfully!', 'success');
      this.renderDashboard('profile');
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // -------------------------------------------------------------
  // TAB: PITCH DECK & NEURAL PARSER
  // -------------------------------------------------------------
  async renderPitchDeckTab(container) {
    const res = await fetch('/api/v1/pitch-decks', { headers: this.getAuthHeaders() });
    const decks = res.ok ? await res.json() : [];
    this.state.pitchDecks = decks;

    container.innerHTML = `
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
        <!-- Left: Upload or Add Deck Form -->
        <div style="background: var(--white); border: 1px solid var(--gray-200); border-radius: var(--radius-lg); padding: 28px; box-shadow: var(--shadow-sm);">
          <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 8px;">Upload & Parse Pitch Deck</h3>
          <p style="color: var(--gray-500); font-size: 0.9rem; margin-bottom: 20px;">
            Upload your PDF or structure your deck attributes to enhance matching confidence.
          </p>

          <form onsubmit="app.handleDeckUpload(event)">
            <div class="form-group">
              <label class="form-label">Deck Title / Round Name</label>
              <input type="text" class="form-input" id="deck-title" required placeholder="Series Seed Investor Deck 2026">
            </div>

            <div class="form-group">
              <label class="form-label">Upload Deck File (PDF)</label>
              <input type="file" class="form-input" id="deck-file" accept=".pdf">
              <span style="font-size: 0.75rem; color: var(--gray-500); margin-top: 4px; display: block;">
                Supported: PDF presentations up to 25MB.
              </span>
            </div>

            <div class="form-group">
              <label class="form-label">The Core Problem</label>
              <textarea class="form-input" id="deck-problem" rows="2" placeholder="What friction or gap does your startup solve?"></textarea>
            </div>

            <div class="form-group">
              <label class="form-label">The Solution</label>
              <textarea class="form-input" id="deck-solution" rows="2" placeholder="How does your technology solve it uniquely?"></textarea>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
              <div class="form-group">
                <label class="form-label">TAM / Market Size</label>
                <input type="text" class="form-input" id="deck-tam" placeholder="$25B Global Market">
              </div>
              <div class="form-group">
                <label class="form-label">Target Raise ($)</label>
                <input type="number" class="form-input" id="deck-raise" value="1500000" step="100000">
              </div>
            </div>

            <button type="submit" class="btn btn-primary full-width" style="margin-top: 12px;">
              Save & Index Pitch Deck
            </button>
          </form>
        </div>

        <!-- Right: Active Indexed Decks -->
        <div>
          <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 16px;">Active Parsed Pitch Decks</h3>
          ${decks.length === 0 ? `
            <div class="stat-card" style="text-align: center; padding: 40px; color: var(--gray-500);">
              No pitch decks uploaded yet. Upload a deck to enable semantic vector scoring!
            </div>
          ` : `
            <div style="display: flex; flex-direction: column; gap: 16px;">
              ${decks.map(d => `
                <div class="stat-card" style="position: relative;">
                  <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                    <div>
                      <h4 style="font-size: 1.15rem; font-weight: 700; color: var(--gray-900);">${d.title}</h4>
                      <span style="font-size: 0.8rem; color: var(--primary-600); font-weight: 600;">
                        ✓ ${d.deck_status}
                      </span>
                    </div>
                    <button class="btn btn-secondary btn-sm" style="color: var(--error-600);" onclick="app.deletePitchDeck(${d.id})">Delete</button>
                  </div>

                  <div style="margin-top: 14px; font-size: 0.875rem; color: var(--gray-700); line-height: 1.5;">
                    <div style="margin-bottom: 6px;"><strong>Problem:</strong> ${d.problem || 'N/A'}</div>
                    <div style="margin-bottom: 6px;"><strong>Solution:</strong> ${d.solution || 'N/A'}</div>
                    <div style="margin-bottom: 6px;"><strong>Market TAM:</strong> ${d.market_size_tam || 'N/A'}</div>
                    <div><strong>Target Raise:</strong> $${(d.target_raise || 0).toLocaleString()}</div>
                  </div>
                </div>
              `).join('')}
            </div>
          `}
        </div>
      </div>
    `;
  },

  async handleDeckUpload(e) {
    e.preventDefault();
    const title = document.getElementById('deck-title').value;
    const fileInput = document.getElementById('deck-file');
    const problem = document.getElementById('deck-problem').value;
    const solution = document.getElementById('deck-solution').value;
    const market_size_tam = document.getElementById('deck-tam').value;
    const target_raise = parseFloat(document.getElementById('deck-raise').value) || 0;

    try {
      if (fileInput.files.length > 0) {
        const formData = new FormData();
        formData.append('file', fileInput.files[0]);
        formData.append('title', title);

        const res = await fetch('/api/v1/pitch-decks/upload', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${this.state.token}` },
          body: formData
        });
        if (!res.ok) throw new Error('File upload failed');
      } else {
        const res = await fetch('/api/v1/pitch-decks', {
          method: 'POST',
          headers: this.getAuthHeaders(),
          body: JSON.stringify({
            title, problem, solution, market_size_tam, target_raise, business_model: 'B2B SaaS Subscription'
          })
        });
        if (!res.ok) throw new Error('Pitch deck creation failed');
      }

      this.showToast('Pitch deck indexed successfully!', 'success');
      this.renderDashboard('pitchdeck');
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async deletePitchDeck(deckId) {
    if (!confirm('Are you sure you want to remove this pitch deck?')) return;
    try {
      const res = await fetch(`/api/v1/pitch-decks/${deckId}`, {
        method: 'DELETE',
        headers: this.getAuthHeaders()
      });
      if (!res.ok) throw new Error('Failed to delete deck');
      this.showToast('Pitch deck deleted.', 'info');
      this.renderDashboard('pitchdeck');
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // -------------------------------------------------------------
  // TAB: MATCHES (INVESTORS OR MENTORS)
  // -------------------------------------------------------------
  async renderMatchesTab(container, role) {
    let url = `/api/v1/matches?role=${role}`;
    const res = await fetch(url, { headers: this.getAuthHeaders() });
    const matches = res.ok ? await res.json() : [];

    container.innerHTML = `
      <div style="margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
          <div>
            <h2 style="font-size: 1.5rem; font-weight: 800; color: var(--gray-900);">
              ${role === 'INVESTOR' ? 'Verified Investor Matches' : (role === 'STARTUP' ? 'Curated Startup Deal Flow' : 'Domain Mentors & Advisors')}
            </h2>
            <p style="color: var(--gray-500); font-size: 0.9rem;">
              Ranked with multi-factor neural embeddings, stage overlap, and check size compatibility.
            </p>
          </div>

          <!-- Controls / Filter -->
          <div style="display: flex; gap: 12px; align-items: center;">
            <select class="form-select" style="width: 160px;" onchange="app.filterMatches(this.value, '${role}')">
              <option value="ALL">All Industries</option>
              <option value="AI/ML">AI / ML</option>
              <option value="FinTech">FinTech</option>
              <option value="HealthTech">HealthTech</option>
              <option value="CleanTech">CleanTech</option>
              <option value="SaaS">SaaS</option>
            </select>
          </div>
        </div>
      </div>

      <div class="matches-grid" id="matches-container">
        ${matches.length === 0 ? `
          <div class="stat-card" style="grid-column: 1 / -1; text-align: center; padding: 48px;">
            <p style="color: var(--gray-500);">No matching candidates found for the specified filters.</p>
          </div>
        ` : matches.map(m => this.createMatchCardHtml(m)).join('')}
      </div>
    `;
  },

  filterMatches(industry, role) {
    const cards = document.querySelectorAll('.match-card');
    cards.forEach(card => {
      const cardInd = card.getAttribute('data-industry') || '';
      if (industry === 'ALL' || cardInd.toLowerCase().includes(industry.toLowerCase())) {
        card.style.display = 'flex';
      } else {
        card.style.display = 'none';
      }
    });
  },

  // -------------------------------------------------------------
  // TAB: SAVED MATCHES
  // -------------------------------------------------------------
  async renderSavedTab(container) {
    const [interRes, matchesRes] = await Promise.all([
      fetch('/api/v1/interactions', { headers: this.getAuthHeaders() }),
      fetch('/api/v1/matches', { headers: this.getAuthHeaders() })
    ]);

    const interactions = interRes.ok ? await interRes.json() : [];
    const allMatches = matchesRes.ok ? await matchesRes.json() : [];

    const savedIds = new Set(interactions.filter(i => i.interaction_type === 'saved').map(i => i.target_user_id));
    const savedCandidates = allMatches.filter(m => savedIds.has(m.user_id));

    container.innerHTML = `
      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 1.5rem; font-weight: 800; color: var(--gray-900);">Saved Candidates</h2>
        <p style="color: var(--gray-500); font-size: 0.9rem;">Bookmarked partners ready for review and outreach.</p>
      </div>

      <div class="matches-grid">
        ${savedCandidates.length === 0 ? `
          <div class="stat-card" style="grid-column: 1 / -1; text-align: center; padding: 48px;">
            <p style="color: var(--gray-500);">You have not saved any candidates yet. Browse matches and click "Save Match" to bookmark them.</p>
            <button class="btn btn-primary" style="margin-top: 12px;" onclick="app.setTab('investors')">Browse Matches</button>
          </div>
        ` : savedCandidates.map(m => this.createMatchCardHtml(m)).join('')}
      </div>
    `;
  },

  // -------------------------------------------------------------
  // TAB: INTERACTIONS & OUTREACH
  // -------------------------------------------------------------
  async renderInteractionsTab(container) {
    const interRes = await fetch('/api/v1/interactions', { headers: this.getAuthHeaders() });
    const interactions = interRes.ok ? await interRes.json() : [];

    container.innerHTML = `
      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 1.5rem; font-weight: 800; color: var(--gray-900);">Active Connections & Intros</h2>
        <p style="color: var(--gray-500); font-size: 0.9rem;">Track your ecosystem introductions, meetings requested, and notes.</p>
      </div>

      <div style="background: var(--white); border: 1px solid var(--gray-200); border-radius: var(--radius-lg); padding: 24px; box-shadow: var(--shadow-sm);">
        ${interactions.length === 0 ? `
          <div style="text-align: center; padding: 40px; color: var(--gray-500);">
            No interactions recorded yet. Request an intro from any candidate card to start a conversation!
          </div>
        ` : `
          <table style="width: 100%; border-collapse: collapse; text-align: left;">
            <thead>
              <tr style="border-bottom: 1px solid var(--gray-200); color: var(--gray-500); font-size: 0.85rem; text-transform: uppercase;">
                <th style="padding: 12px 16px;">Target Partner ID</th>
                <th style="padding: 12px 16px;">Type</th>
                <th style="padding: 12px 16px;">Notes / Context</th>
                <th style="padding: 12px 16px;">Status</th>
                <th style="padding: 12px 16px;">Date</th>
              </tr>
            </thead>
            <tbody>
              ${interactions.map(i => `
                <tr style="border-bottom: 1px solid var(--gray-100); font-size: 0.9rem;">
                  <td style="padding: 14px 16px; font-weight: 600;">Partner #${i.target_user_id}</td>
                  <td style="padding: 14px 16px;"><span class="check-pill active">${i.interaction_type}</span></td>
                  <td style="padding: 14px 16px; color: var(--gray-600);">${i.notes || 'Introduction initiated'}</td>
                  <td style="padding: 14px 16px;">
                    <span style="font-weight: 700; color: var(--success-600);">● ${i.status}</span>
                  </td>
                  <td style="padding: 14px 16px; color: var(--gray-500); font-size: 0.8rem;">
                    ${new Date(i.created_at).toLocaleDateString()}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `}
      </div>
    `;
  },

  // -------------------------------------------------------------
  // MATCH CARD COMPONENT & INTERACTIONS
  // -------------------------------------------------------------
  createMatchCardHtml(candidate) {
    const exp = candidate.explainability;
    const isSaved = candidate.is_saved;

    return `
      <div class="match-card" data-industry="${candidate.industry || ''}" id="card-user-${candidate.user_id}">
        <div class="match-card-header">
          <div>
            <h3 class="candidate-name">${candidate.company_or_firm_name || candidate.full_name}</h3>
            <span style="font-size: 0.85rem; color: var(--gray-500);">${candidate.full_name} • ${candidate.role}</span>
          </div>
          <span class="match-score-badge" style="font-size: 0.9rem;">
            ${exp.overall_score}% Match
          </span>
        </div>

        <div class="candidate-badges">
          <span class="check-pill active">${candidate.industry || 'Tech'}</span>
          <span class="check-pill active">${candidate.stage || 'Seed'}</span>
          ${candidate.ticket_size_max ? `<span class="check-pill active">$${(candidate.ticket_size_min/1000).toFixed(0)}K – $${(candidate.ticket_size_max/1000).toFixed(0)}K</span>` : ''}
        </div>

        <p class="candidate-desc">
          ${candidate.tagline || candidate.bio || candidate.skills_or_thesis || 'Active participant in the venture ecosystem.'}
        </p>

        <!-- Explainability Box -->
        <div class="preview-why-box" style="margin-bottom: 16px;">
          <div class="preview-why-title">Why this match?</div>
          <div class="preview-why-desc">
            ${exp.synergy_summary}
          </div>
        </div>

        <div class="match-card-actions">
          <button class="btn ${isSaved ? 'btn-secondary' : 'btn-outline-white'}" style="${!isSaved ? 'color: var(--primary-600); border-color: var(--primary-200);' : ''} flex: 1;" onclick="app.toggleSaveMatch(${candidate.user_id})">
            ${isSaved ? '★ Saved' : '☆ Save Match'}
          </button>
          <button class="btn btn-primary" style="flex: 1;" onclick="app.openConnectModal(${candidate.user_id}, '${escape(candidate.company_or_firm_name || candidate.full_name)}')">
            Connect →
          </button>
          <button class="btn btn-ghost" title="Inspect Neural Breakdown" onclick="app.openExplainModal(${candidate.user_id})">
            ℹ
          </button>
        </div>
      </div>
    `;
  },

  async toggleSaveMatch(targetUserId) {
    try {
      const res = await fetch('/api/v1/interactions', {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({
          target_user_id: targetUserId,
          interaction_type: 'saved',
          notes: 'Saved to bookmarks'
        })
      });
      if (!res.ok) throw new Error('Could not update saved status');
      this.showToast('Candidate saved to your bookmarks!', 'success');
      this.renderDashboard(this.state.dashboardTab);
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  openConnectModal(targetUserId, encodedName) {
    const partnerName = unescape(encodedName);
    const backdrop = document.getElementById('modal-backdrop');
    const modalContent = document.getElementById('modal-content');

    modalContent.innerHTML = `
      <div class="modal-header">
        <h3 class="modal-title">Request Introduction with ${partnerName}</h3>
        <button class="modal-close" onclick="app.closeModal()">&times;</button>
      </div>
      <form onsubmit="app.handleSendIntro(event, ${targetUserId})">
        <div class="form-group">
          <label class="form-label">Personalized Introduction Note</label>
          <textarea class="form-input" id="intro-note" rows="4" required placeholder="Hi ${partnerName}, we noticed strong alignment with our thesis and would love to share our latest metrics and pitch deck..."></textarea>
        </div>
        <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 16px;">
          <button type="button" class="btn btn-secondary" onclick="app.closeModal()">Cancel</button>
          <button type="submit" class="btn btn-primary">Send Introduction Request</button>
        </div>
      </form>
    `;
    backdrop.classList.add('active');
  },

  async handleSendIntro(e, targetUserId) {
    e.preventDefault();
    const note = document.getElementById('intro-note').value;
    try {
      const res = await fetch('/api/v1/interactions', {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({
          target_user_id: targetUserId,
          interaction_type: 'connected',
          notes: note
        })
      });
      if (!res.ok) throw new Error('Failed to request intro');
      this.closeModal();
      this.showToast('Introduction request sent successfully!', 'success');
      this.renderDashboard(this.state.dashboardTab);
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async openExplainModal(targetUserId) {
    // Fetch matches to find candidate explainability details
    const res = await fetch('/api/v1/matches', { headers: this.getAuthHeaders() });
    const matches = res.ok ? await res.json() : [];
    const candidate = matches.find(m => m.user_id === targetUserId);
    if (!candidate) return;

    const exp = candidate.explainability;
    const backdrop = document.getElementById('modal-backdrop');
    const modalContent = document.getElementById('modal-content');

    modalContent.innerHTML = `
      <div class="modal-header">
        <div>
          <span style="font-size: 0.8rem; font-weight: 700; color: var(--gray-500); text-transform: uppercase;">Neural Breakdown</span>
          <h3 class="modal-title">${candidate.company_or_firm_name || candidate.full_name}</h3>
        </div>
        <button class="modal-close" onclick="app.closeModal()">&times;</button>
      </div>

      <div style="margin: 20px 0;">
        <div class="explain-score-header" style="margin-bottom: 24px;">
          <div>
            <span style="font-size: 0.85rem; color: var(--gray-500);">Compatibility Confidence</span>
            <div style="font-size: 1.1rem; font-weight: 700; color: var(--gray-900);">Multi-Factor Match Score</div>
          </div>
          <div class="score-huge">${exp.overall_score}%</div>
        </div>

        <div class="breakdown-row">
          <div class="breakdown-label-group"><span>Industry Alignment</span><span>${exp.industry_score}%</span></div>
          <div class="progress-track"><div class="progress-fill" style="width: ${exp.industry_score}%;"></div></div>
        </div>
        <div class="breakdown-row">
          <div class="breakdown-label-group"><span>Stage Compatibility</span><span>${exp.stage_score}%</span></div>
          <div class="progress-track"><div class="progress-fill" style="width: ${exp.stage_score}%;"></div></div>
        </div>
        <div class="breakdown-row">
          <div class="breakdown-label-group"><span>Ticket Size Fit</span><span>${exp.ticket_fit_score}%</span></div>
          <div class="progress-track"><div class="progress-fill" style="width: ${exp.ticket_fit_score}%;"></div></div>
        </div>
        <div class="breakdown-row">
          <div class="breakdown-label-group"><span>Semantic Thesis Match</span><span>${exp.semantic_thesis_score}%</span></div>
          <div class="progress-track"><div class="progress-fill" style="width: ${exp.semantic_thesis_score}%;"></div></div>
        </div>
        <div class="breakdown-row">
          <div class="breakdown-label-group"><span>Domain Track Record</span><span>${exp.domain_score}%</span></div>
          <div class="progress-track"><div class="progress-fill" style="width: ${exp.domain_score}%;"></div></div>
        </div>

        <div style="margin-top: 20px;">
          <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 8px;">Key Contribution Drivers:</h4>
          <ul style="padding-left: 20px; font-size: 0.875rem; color: var(--gray-700); line-height: 1.6;">
            ${exp.reasons.map(r => `<li>${r}</li>`).join('')}
          </ul>
        </div>
      </div>

      <div style="display: flex; justify-content: flex-end;">
        <button class="btn btn-secondary" onclick="app.closeModal()">Close</button>
      </div>
    `;

    backdrop.classList.add('active');
  },

  // -------------------------------------------------------------
  // AUTH MODALS & USER HANDLING
  // -------------------------------------------------------------
  showAuthModal(mode = 'login', role = 'STARTUP') {
    const backdrop = document.getElementById('modal-backdrop');
    const modalContent = document.getElementById('modal-content');

    if (mode === 'login') {
      modalContent.innerHTML = `
        <div class="modal-header">
          <h3 class="modal-title">Sign in to Starto AI</h3>
          <button class="modal-close" onclick="app.closeModal()">&times;</button>
        </div>
        <form onsubmit="app.handleLogin(event)">
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <input type="email" class="form-input" id="auth-email" required placeholder="founder@acme.ai">
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" class="form-input" id="auth-password" required placeholder="••••••••">
          </div>
          <button type="submit" class="btn btn-primary full-width" style="margin-top: 10px;">Sign In</button>
          
          <div style="margin-top: 14px; text-align: center; font-size: 0.8rem; color: var(--gray-500);">
            Quick Demo Accounts:
            <div style="display: flex; gap: 8px; justify-content: center; margin-top: 6px;">
              <button type="button" class="btn btn-secondary btn-sm" onclick="app.demoQuickLogin('founder')">Alex (Founder)</button>
              <button type="button" class="btn btn-secondary btn-sm" onclick="app.demoQuickLogin('investor')">Elena (Investor)</button>
            </div>
          </div>

          <p style="margin-top: 16px; font-size: 0.85rem; text-align: center; color: var(--gray-600);">
            Don't have an account? <a href="#" style="color: var(--primary-600); font-weight: 600;" onclick="app.showAuthModal('register')">Sign Up</a>
          </p>
        </form>
      `;
    } else {
      modalContent.innerHTML = `
        <div class="modal-header">
          <h3 class="modal-title">Create your Account</h3>
          <button class="modal-close" onclick="app.closeModal()">&times;</button>
        </div>
        <form onsubmit="app.handleRegister(event)">
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input type="text" class="form-input" id="reg-name" required placeholder="Jane Doe">
          </div>
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <input type="email" class="form-input" id="reg-email" required placeholder="jane@venture.io">
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" class="form-input" id="reg-password" required placeholder="••••••••">
          </div>
          <div class="form-group">
            <label class="form-label">I am joining as a:</label>
            <select class="form-select" id="reg-role">
              <option value="STARTUP" ${role === 'STARTUP' ? 'selected' : ''}>Startup Founder</option>
              <option value="INVESTOR" ${role === 'INVESTOR' ? 'selected' : ''}>Investor</option>
              <option value="MENTOR" ${role === 'MENTOR' ? 'selected' : ''}>Mentor / Advisor</option>
              <option value="ADMIN">Administrator</option>
            </select>
          </div>
          <button type="submit" class="btn btn-primary full-width" style="margin-top: 10px;">Create Account</button>
          <p style="margin-top: 16px; font-size: 0.85rem; text-align: center; color: var(--gray-600);">
            Already have an account? <a href="#" style="color: var(--primary-600); font-weight: 600;" onclick="app.showAuthModal('login')">Sign In</a>
          </p>
        </form>
      `;
    }

    backdrop.classList.add('active');
  },

  closeModal(e) {
    if (e && e.target !== e.currentTarget && !e.target.classList.contains('modal-close')) return;
    document.getElementById('modal-backdrop').classList.remove('active');
  },

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => {
      toast.remove();
    }, 3500);
  },

  toggleMobileMenu() {
    const drawer = document.getElementById('mobile-nav-drawer');
    drawer.classList.toggle('open');
  },

  closeMobileMenu() {
    const drawer = document.getElementById('mobile-nav-drawer');
    drawer.classList.remove('open');
  },

  async handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('auth-email').value;
    const password = document.getElementById('auth-password').value;

    try {
      const res = await fetch('/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        const errorMsg = data.message || (typeof data.detail === 'string' ? data.detail : 'Login failed.');
        throw new Error(errorMsg);
      }
      this.state.token = data.access_token;
      this.state.user = data.user;
      localStorage.setItem('starto_token', data.access_token);
      localStorage.setItem('starto_user', JSON.stringify(data.user));
      this.closeModal();
      this.showToast(`Welcome back, ${data.user.full_name}!`, 'success');
      this.renderDashboard();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async handleRegister(e) {
    e.preventDefault();
    const full_name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;
    const role = document.getElementById('reg-role').value;

    try {
      const res = await fetch('/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ full_name, email, password, role })
      });
      const data = await res.json();
      if (!res.ok) {
        const errorMsg = data.message || (typeof data.detail === 'string' ? data.detail : 'Registration failed.');
        throw new Error(errorMsg);
      }
      this.showToast('Account created successfully! Welcome to Starto AI.', 'success');
      if (data.access_token && data.user) {
        this.state.token = data.access_token;
        this.state.user = data.user;
        localStorage.setItem('starto_token', data.access_token);
        localStorage.setItem('starto_user', JSON.stringify(data.user));
        this.closeModal();
        this.renderDashboard();
      } else {
        this.showAuthModal('login');
      }
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  logout() {
    localStorage.removeItem('starto_token');
    localStorage.removeItem('starto_user');
    this.state.token = null;
    this.state.user = null;
    this.renderLanding();
    this.showToast('Logged out successfully.', 'info');
  }
};

window.addEventListener('DOMContentLoaded', () => {
  app.init();
});
