import logging
from typing import Generator
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, declarative_base
from backend.app.config import settings

logger = logging.getLogger("starto_ai.database")

def get_engine_and_url():
    db_url = settings.DATABASE_URL
    connect_args = {}
    
    if db_url.startswith("sqlite"):
        connect_args["check_same_thread"] = False
        engine = create_engine(db_url, connect_args=connect_args)
        logger.info(f"Using SQLite database engine at {db_url}")
        return engine, db_url
    
    # Attempt PostgreSQL connection
    try:
        engine = create_engine(db_url, pool_pre_ping=True)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info("Successfully connected to primary PostgreSQL database.")
        return engine, db_url
    except Exception as exc:
        logger.warning(
            f"PostgreSQL connection to {db_url} failed ({exc}). "
            f"Falling back to local SQLite database for development reliability."
        )
        sqlite_url = "sqlite:///./starto_ai.db"
        fallback_engine = create_engine(sqlite_url, connect_args={"check_same_thread": False})
        return fallback_engine, sqlite_url


engine, active_db_url = get_engine_and_url()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db() -> Generator:
    """Dependency that provides a database session and ensures closure."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def check_database_connection() -> dict:
    """Checks database health and dialect."""
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {
            "status": "healthy",
            "dialect": engine.dialect.name,
            "url": str(engine.url).split("@")[-1] if "@" in str(engine.url) else str(engine.url)
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }


def init_db():
    """Initializes tables in database."""
    # Import all models so metadata knows about them
    import backend.app.models  # noqa: F401
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables initialized successfully.")


# Ensure tables exist on load
init_db()


