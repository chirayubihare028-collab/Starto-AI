from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List, Union

BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    PROJECT_NAME: str = "Starto AI"
    PROJECT_TITLE: str = "AI-Powered Startup-Investor-Mentor Matching Ecosystem"
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    
    # API & Network
    API_PORT: int = 8000
    API_HOST: str = "0.0.0.0"
    CORS_ORIGINS: Union[str, List[str]] = ["*"]
    
    # Database
    DATABASE_URL: str = "sqlite:///./starto_ai.db"
    POSTGRES_DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/starto_ai"
    
    # Security
    JWT_SECRET_KEY: str = "starto-ai-super-secret-production-grade-key-change-in-prod-2026"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    
    # ML & Vector Engine
    MODEL_NAME: str = "sentence-transformers/all-MiniLM-L6-v2"
    FAISS_INDEX_PATH: str = str(BASE_DIR / "data" / "faiss_index")
    EMBEDDING_DIMENSION: int = 384
    
    # Neo4j Graph Database
    NEO4J_URI: str = "bolt://localhost:7687"
    NEO4J_USERNAME: str = "neo4j"
    NEO4J_PASSWORD: str = "starto_password"

    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore"
    )

    def get_cors_origins(self) -> List[str]:
        if isinstance(self.CORS_ORIGINS, list):
            return self.CORS_ORIGINS
        if isinstance(self.CORS_ORIGINS, str):
            if self.CORS_ORIGINS.strip() == "*":
                return ["*"]
            return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]
        return ["*"]


settings = Settings()
