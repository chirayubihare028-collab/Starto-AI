from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.schemas.user import UserRegister, UserLogin, Token, UserResponse, RegisterResponse
from backend.app.services.auth_service import AuthService, get_current_user

router = APIRouter(tags=["Authentication"])


@router.post("/auth/register", response_model=RegisterResponse, status_code=status.HTTP_201_CREATED)
@router.post("/api/v1/auth/register", response_model=RegisterResponse, status_code=status.HTTP_201_CREATED, include_in_schema=False)
def register(user_in: UserRegister, db: Session = Depends(get_db)):
    """Registers a new user account (Startup Founder, Investor, Mentor, or Admin)."""
    try:
        user = AuthService.register(db=db, user_data=user_in)
        token_payload = {
            "sub": str(user.id),
            "email": user.email,
            "role": user.role
        }
        from backend.app.utils.security import create_access_token
        access_token = create_access_token(data=token_payload)
        return RegisterResponse(
            message="Account created successfully!",
            user=UserResponse.model_validate(user),
            access_token=access_token,
            token_type="bearer"
        )
    except HTTPException as e:
        raise HTTPException(
            status_code=e.status_code,
            detail={"message": e.detail, "error": "RegistrationError"} if isinstance(e.detail, str) else e.detail
        )


@router.post("/auth/login", response_model=Token, status_code=status.HTTP_200_OK)
@router.post("/api/v1/auth/login", response_model=Token, status_code=status.HTTP_200_OK, include_in_schema=False)
def login(login_in: UserLogin, db: Session = Depends(get_db)):
    """Authenticates credentials and returns a JWT access token."""
    try:
        return AuthService.login(db=db, login_data=login_in)
    except HTTPException as e:
        raise HTTPException(
            status_code=e.status_code,
            detail={"message": e.detail, "error": "AuthenticationError"} if isinstance(e.detail, str) else e.detail
        )


@router.get("/auth/me", response_model=UserResponse)
@router.get("/api/v1/auth/me", response_model=UserResponse, include_in_schema=False)
def get_authenticated_profile(current_user: User = Depends(get_current_user)):
    """Retrieves profile details for the currently authenticated user."""
    return UserResponse.model_validate(current_user)
