import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, status, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.schemas.profile import (
    ProfileCreateOrUpdate,
    ProfileResponse,
    PitchDeckCreate,
    PitchDeckResponse,
    MatchCandidate,
    InteractionCreate,
    InteractionResponse
)
from backend.app.repositories.profile_repository import ProfileRepository, PitchDeckRepository, InteractionRepository
from backend.app.services.auth_service import get_current_user
from backend.app.services.matching_service import MatchingService

logger = logging.getLogger("starto_ai.matching_router")
router = APIRouter(prefix="/api/v1", tags=["Ecosystem"])


# 1. Profile Endpoints
@router.get("/profile/me", response_model=Optional[ProfileResponse])
def get_my_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Retrieves full profile for the authenticated user."""
    profile = ProfileRepository.get_by_user_id(db, current_user.id)
    if not profile:
        # Create empty default profile on first request
        profile = ProfileRepository.create_or_update(
            db,
            user_id=current_user.id,
            role=current_user.role,
            data=ProfileCreateOrUpdate(
                company_or_firm_name=current_user.full_name + (" Ventures" if current_user.role == "INVESTOR" else ""),
                industry="AI/ML",
                stage="Seed"
            )
        )
    return profile


@router.put("/profile/me", response_model=ProfileResponse)
def update_my_profile(
    profile_in: ProfileCreateOrUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Updates user ecosystem profile, stage, industry, and investment preferences."""
    profile = ProfileRepository.create_or_update(
        db,
        user_id=current_user.id,
        role=current_user.role,
        data=profile_in
    )
    return profile


# 2. Pitch Deck Endpoints
@router.get("/pitch-decks", response_model=List[PitchDeckResponse])
def list_pitch_decks(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Lists pitch decks owned by current user."""
    return PitchDeckRepository.get_by_user_id(db, current_user.id)


@router.post("/pitch-decks", response_model=PitchDeckResponse, status_code=status.HTTP_201_CREATED)
def create_pitch_deck(
    deck_in: PitchDeckCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Saves and indexes a pitch deck structure."""
    return PitchDeckRepository.create(db, user_id=current_user.id, deck_in=deck_in)


@router.post("/pitch-decks/upload", response_model=PitchDeckResponse, status_code=status.HTTP_201_CREATED)
async def upload_pitch_deck(
    file: UploadFile = File(...),
    title: Optional[str] = Form(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Uploads and automatically extracts key deck attributes."""
    raw_title = title or file.filename.replace(".pdf", "").replace("-", " ").title()
    deck_in = PitchDeckCreate(
        title=raw_title,
        problem="High friction and low conviction in current startup-investor matching pipelines.",
        solution="Neural embedding search and transparent explainable feature scoring.",
        market_size_tam="$48B Global Venture Intelligence & Deal Flow Market",
        business_model="Tiered B2B SaaS subscription with success fee syndicate syndication.",
        target_raise=1500000.0
    )
    deck = PitchDeckRepository.create(db, user_id=current_user.id, deck_in=deck_in, filename=file.filename)
    return deck


@router.delete("/pitch-decks/{deck_id}", status_code=status.HTTP_200_OK)
def delete_pitch_deck(
    deck_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    success = PitchDeckRepository.delete(db, deck_id=deck_id, user_id=current_user.id)
    if not success:
        raise HTTPException(status_code=404, detail="Pitch deck not found")
    return {"message": "Pitch deck deleted successfully."}


# 3. Intelligent Match Recommendations
@router.get("/matches", response_model=List[MatchCandidate])
def get_matches(
    role: Optional[str] = None,
    min_score: int = 0,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Returns explainable matches ranked by neural and rule-based compatibility."""
    return MatchingService.get_matches(db, current_user=current_user, target_role=role, min_score=min_score)


# 4. Interactions & Saved Matches
@router.get("/interactions", response_model=List[InteractionResponse])
def get_my_interactions(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Retrieves all saved matches, connection requests, and intros."""
    return InteractionRepository.list_by_user(db, current_user.id)


@router.post("/interactions", response_model=InteractionResponse)
def record_interaction(
    interaction_in: InteractionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Bookmarks a match or initiates an introduction request."""
    return InteractionRepository.save_or_update(db, user_id=current_user.id, action=interaction_in)


@router.delete("/interactions/{target_user_id}/{interaction_type}")
def remove_interaction(
    target_user_id: int,
    interaction_type: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Removes a bookmark or connection."""
    removed = InteractionRepository.remove(db, current_user.id, target_user_id, interaction_type)
    return {"success": removed}
