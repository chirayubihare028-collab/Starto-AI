from typing import Optional, List, Dict, Any
from pydantic import BaseModel, ConfigDict
from datetime import datetime


class ProfileBase(BaseModel):
    company_or_firm_name: Optional[str] = None
    tagline: Optional[str] = None
    bio: Optional[str] = None
    website: Optional[str] = None
    location: Optional[str] = None
    industry: Optional[str] = None
    stage: Optional[str] = None
    ticket_size_min: Optional[float] = 0.0
    ticket_size_max: Optional[float] = 0.0
    traction_arr: Optional[float] = 0.0
    skills_or_thesis: Optional[str] = None


class ProfileCreateOrUpdate(ProfileBase):
    pass


class ProfileResponse(ProfileBase):
    id: int
    user_id: int
    role: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class PitchDeckCreate(BaseModel):
    title: str
    problem: Optional[str] = None
    solution: Optional[str] = None
    market_size_tam: Optional[str] = None
    business_model: Optional[str] = None
    target_raise: Optional[float] = 0.0


class PitchDeckResponse(PitchDeckCreate):
    id: int
    user_id: int
    filename: Optional[str] = None
    deck_status: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class MatchExplainability(BaseModel):
    overall_score: int  # 0 - 100
    industry_score: int
    stage_score: int
    ticket_fit_score: int
    semantic_thesis_score: int
    domain_score: int
    reasons: List[str]
    synergy_summary: str


class MatchCandidate(BaseModel):
    user_id: int
    role: str
    full_name: str
    email: str
    company_or_firm_name: Optional[str] = None
    tagline: Optional[str] = None
    bio: Optional[str] = None
    industry: Optional[str] = None
    stage: Optional[str] = None
    ticket_size_min: Optional[float] = 0.0
    ticket_size_max: Optional[float] = 0.0
    traction_arr: Optional[float] = 0.0
    skills_or_thesis: Optional[str] = None
    explainability: MatchExplainability
    is_saved: bool = False
    interaction_status: Optional[str] = None


class InteractionCreate(BaseModel):
    target_user_id: int
    interaction_type: str  # 'saved', 'connected', 'requested_intro', 'message'
    notes: Optional[str] = None


class InteractionResponse(BaseModel):
    id: int
    user_id: int
    target_user_id: int
    interaction_type: str
    notes: Optional[str] = None
    status: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
