import logging
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Request, status, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from backend.app.config import settings
from backend.app.database import check_database_connection, init_db
from backend.app.routers.auth import router as auth_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("starto_ai")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing Starto AI application and database...")
    init_db()
    yield
    logger.info("Shutting down Starto AI application.")


app = FastAPI(
    title=settings.PROJECT_TITLE,
    version=settings.VERSION,
    description="Intelligent AI-Powered Matching Ecosystem connecting Startups, Investors, and Mentors.",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS
cors_origins = settings.get_cors_origins()
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins if cors_origins != ["*"] else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    msg = exc.detail
    if isinstance(msg, dict) and "message" in msg:
        msg = msg["message"]
    return JSONResponse(
        status_code=exc.status_code,
        content={"message": str(msg), "detail": exc.detail},
        headers=exc.headers
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = exc.errors()
    first_error = errors[0]["msg"] if errors else "Validation error"
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"message": f"Input validation error: {first_error}", "detail": errors}
    )


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception on {request.method} {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "InternalServerError",
            "message": "An unexpected error occurred. Please try again or contact support.",
            "path": request.url.path
        }
    )


# Include Routers
app.include_router(auth_router)
from backend.app.routers.matching import router as matching_router
app.include_router(matching_router)


@app.get("/health", tags=["System"])
def health_check():
    """System health check endpoint verifying database connectivity and configuration."""
    db_status = check_database_connection()
    is_healthy = db_status.get("status") == "healthy"
    
    return {
        "status": "healthy" if is_healthy else "degraded",
        "service": settings.PROJECT_NAME,
        "title": settings.PROJECT_TITLE,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "database": db_status
    }


@app.get("/api/v1/info", tags=["System"])
def system_info():
    """High-level system capabilities and active architecture information."""
    return {
        "name": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "matching_pipeline": [
            "Structured Profile Filtering",
            "Rule-Based Compatibility",
            "Sentence Transformer Embeddings (all-MiniLM-L6-v2)",
            "FAISS Candidate Retrieval with Cosine Fallback",
            "Multi-Factor Learning-to-Rank",
            "Explainable AI & Feature Contribution"
        ],
        "database_status": check_database_connection()
    }


# Static Frontend mount
frontend_public_dir = Path(__file__).resolve().parent.parent.parent / "frontend" / "public"
if frontend_public_dir.exists():
    app.mount("/static", StaticFiles(directory=str(frontend_public_dir)), name="static")

    @app.get("/", include_in_schema=False)
    async def serve_index():
        index_file = frontend_public_dir / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file))
        return {
            "message": "Starto AI Backend is running.",
            "docs": "/docs",
            "health": "/health"
        }
else:
    @app.get("/", include_in_schema=False)
    async def root():
        return {
            "message": "Starto AI API is active.",
            "docs": "/docs",
            "health": "/health"
        }
