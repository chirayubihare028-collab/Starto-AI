from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from backend.app.models.user import User
from backend.app.models.profile import Profile, PitchDeck, Interaction
from backend.app.schemas.profile import MatchCandidate, MatchExplainability


def calculate_match_score(
    source_user: User,
    source_profile: Optional[Profile],
    source_decks: List[PitchDeck],
    candidate_user: User,
    candidate_profile: Optional[Profile],
    saved_ids: set,
    interaction_map: Dict[int, str]
) -> MatchCandidate:
    # Defaults
    s_ind = (source_profile.industry if source_profile and source_profile.industry else "AI/ML").lower()
    c_ind = (candidate_profile.industry if candidate_profile and candidate_profile.industry else "AI/ML").lower()

    s_stage = (source_profile.stage if source_profile and source_profile.stage else "Seed").lower()
    c_stage = (candidate_profile.stage if candidate_profile and candidate_profile.stage else "Seed").lower()

    s_ticket_min = source_profile.ticket_size_min if source_profile else 100000.0
    s_ticket_max = source_profile.ticket_size_max if source_profile else 1000000.0
    c_ticket_min = candidate_profile.ticket_size_min if candidate_profile else 250000.0
    c_ticket_max = candidate_profile.ticket_size_max if candidate_profile else 1500000.0

    # 1. Industry Alignment (25%)
    if s_ind in c_ind or c_ind in s_ind:
        industry_score = 95
    else:
        # Related cross-vertical points
        industry_score = 75

    # 2. Stage Compatibility (25%)
    if s_stage == c_stage:
        stage_score = 95
    elif ("seed" in s_stage and "seed" in c_stage) or ("growth" in s_stage and "series" in c_stage):
        stage_score = 88
    else:
        stage_score = 70

    # 3. Ticket Fit (20%)
    # Overlap calculation
    overlap = max(0.0, min(s_ticket_max or 1000000, c_ticket_max or 1000000) - max(s_ticket_min or 100000, c_ticket_min or 100000))
    if overlap > 0:
        ticket_fit_score = 94
    else:
        ticket_fit_score = 72

    # 4. Semantic Thesis Score (15%)
    s_text = (source_profile.skills_or_thesis or "") if source_profile else ""
    if source_decks:
        s_text += " " + (source_decks[0].problem or "") + " " + (source_decks[0].solution or "")
    c_text = (candidate_profile.skills_or_thesis or "") if candidate_profile else ""

    # Token overlap heuristic (representing sentence-transformers similarity)
    s_tokens = set(s_text.lower().split())
    c_tokens = set(c_text.lower().split())
    overlap_tokens = len(s_tokens.intersection(c_tokens))
    semantic_thesis_score = min(98, 80 + overlap_tokens * 3)

    # 5. Domain & Track Record Score (15%)
    domain_score = 86 if candidate_profile and candidate_profile.company_or_firm_name else 78

    overall_score = int(
        industry_score * 0.25 +
        stage_score * 0.25 +
        ticket_fit_score * 0.20 +
        semantic_thesis_score * 0.15 +
        domain_score * 0.15
    )
    overall_score = max(60, min(99, overall_score))

    reasons = [
        f"Direct market alignment in {candidate_profile.industry if candidate_profile and candidate_profile.industry else 'technology'}",
        f"Compatible stage focus ({candidate_profile.stage if candidate_profile and candidate_profile.stage else 'Seed'})",
        f"Capital requirements fall within active investment deployment mandate"
    ]
    if candidate_profile and candidate_profile.skills_or_thesis:
        reasons.append(f"High thesis alignment: {candidate_profile.skills_or_thesis[:70]}...")

    synergy_summary = (
        f"Exceptional synergy with {candidate_profile.company_or_firm_name if candidate_profile and candidate_profile.company_or_firm_name else candidate_user.full_name} "
        f"driven by shared focus on {candidate_profile.industry if candidate_profile and candidate_profile.industry else 'emerging tech'} "
        f"and compatible {candidate_profile.stage if candidate_profile and candidate_profile.stage else 'stage'} positioning."
    )

    explainability = MatchExplainability(
        overall_score=overall_score,
        industry_score=industry_score,
        stage_score=stage_score,
        ticket_fit_score=ticket_fit_score,
        semantic_thesis_score=semantic_thesis_score,
        domain_score=domain_score,
        reasons=reasons,
        synergy_summary=synergy_summary
    )

    return MatchCandidate(
        user_id=candidate_user.id,
        role=candidate_user.role,
        full_name=candidate_user.full_name,
        email=candidate_user.email,
        company_or_firm_name=candidate_profile.company_or_firm_name if candidate_profile else None,
        tagline=candidate_profile.tagline if candidate_profile else None,
        bio=candidate_profile.bio if candidate_profile else None,
        industry=candidate_profile.industry if candidate_profile else None,
        stage=candidate_profile.stage if candidate_profile else None,
        ticket_size_min=candidate_profile.ticket_size_min if candidate_profile else 0.0,
        ticket_size_max=candidate_profile.ticket_size_max if candidate_profile else 0.0,
        traction_arr=candidate_profile.traction_arr if candidate_profile else 0.0,
        skills_or_thesis=candidate_profile.skills_or_thesis if candidate_profile else None,
        explainability=explainability,
        is_saved=candidate_user.id in saved_ids,
        interaction_status=interaction_map.get(candidate_user.id)
    )


class MatchingService:
    @staticmethod
    def get_matches(
        db: Session,
        current_user: User,
        target_role: Optional[str] = None,
        min_score: int = 0
    ) -> List[MatchCandidate]:
        # Determine target role if not explicitly specified
        if not target_role:
            if current_user.role == "STARTUP":
                target_role = "INVESTOR"
            elif current_user.role == "INVESTOR":
                target_role = "STARTUP"
            elif current_user.role == "MENTOR":
                target_role = "STARTUP"
            else:
                target_role = "INVESTOR"

        source_profile = db.query(Profile).filter(Profile.user_id == current_user.id).first()
        source_decks = db.query(PitchDeck).filter(PitchDeck.user_id == current_user.id).all()

        candidates = (
            db.query(User)
            .filter(User.role == target_role, User.id != current_user.id, User.is_active == True)
            .all()
        )

        # Get saved and interactions for current user
        interactions = db.query(Interaction).filter(Interaction.user_id == current_user.id).all()
        saved_ids = {i.target_user_id for i in interactions if i.interaction_type == "saved"}
        interaction_map = {i.target_user_id: i.status for i in interactions}

        matches: List[MatchCandidate] = []
        for candidate in candidates:
            c_profile = db.query(Profile).filter(Profile.user_id == candidate.id).first()
            match_item = calculate_match_score(
                source_user=current_user,
                source_profile=source_profile,
                source_decks=source_decks,
                candidate_user=candidate,
                candidate_profile=c_profile,
                saved_ids=saved_ids,
                interaction_map=interaction_map
            )
            if match_item.explainability.overall_score >= min_score:
                matches.append(match_item)

        # Sort by overall score descending
        matches.sort(key=lambda m: m.explainability.overall_score, reverse=True)
        return matches
