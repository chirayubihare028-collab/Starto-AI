from typing import Optional, List
from sqlalchemy.orm import Session
from backend.app.models.profile import Profile, PitchDeck, Interaction
from backend.app.schemas.profile import ProfileCreateOrUpdate, PitchDeckCreate, InteractionCreate


class ProfileRepository:
    @staticmethod
    def get_by_user_id(db: Session, user_id: int) -> Optional[Profile]:
        return db.query(Profile).filter(Profile.user_id == user_id).first()

    @staticmethod
    def create_or_update(db: Session, user_id: int, role: str, data: ProfileCreateOrUpdate) -> Profile:
        profile = db.query(Profile).filter(Profile.user_id == user_id).first()
        data_dict = data.model_dump(exclude_unset=True)
        if not profile:
            profile = Profile(user_id=user_id, role=role, **data_dict)
            db.add(profile)
        else:
            for k, v in data_dict.items():
                setattr(profile, k, v)
        db.commit()
        db.refresh(profile)
        return profile


class PitchDeckRepository:
    @staticmethod
    def get_by_user_id(db: Session, user_id: int) -> List[PitchDeck]:
        return db.query(PitchDeck).filter(PitchDeck.user_id == user_id).order_by(PitchDeck.id.desc()).all()

    @staticmethod
    def create(db: Session, user_id: int, deck_in: PitchDeckCreate, filename: Optional[str] = None) -> PitchDeck:
        deck = PitchDeck(
            user_id=user_id,
            title=deck_in.title,
            filename=filename or f"{deck_in.title.lower().replace(' ', '_')}.pdf",
            problem=deck_in.problem,
            solution=deck_in.solution,
            market_size_tam=deck_in.market_size_tam,
            business_model=deck_in.business_model,
            target_raise=deck_in.target_raise or 0.0,
            deck_status="Parsed & Ready"
        )
        db.add(deck)
        db.commit()
        db.refresh(deck)
        return deck

    @staticmethod
    def delete(db: Session, deck_id: int, user_id: int) -> bool:
        deck = db.query(PitchDeck).filter(PitchDeck.id == deck_id, PitchDeck.user_id == user_id).first()
        if deck:
            db.delete(deck)
            db.commit()
            return True
        return False


class InteractionRepository:
    @staticmethod
    def list_by_user(db: Session, user_id: int) -> List[Interaction]:
        return db.query(Interaction).filter(Interaction.user_id == user_id).order_by(Interaction.id.desc()).all()

    @staticmethod
    def save_or_update(db: Session, user_id: int, action: InteractionCreate) -> Interaction:
        interaction = db.query(Interaction).filter(
            Interaction.user_id == user_id,
            Interaction.target_user_id == action.target_user_id,
            Interaction.interaction_type == action.interaction_type
        ).first()

        if interaction:
            if action.notes:
                interaction.notes = action.notes
            interaction.status = "Connected" if action.interaction_type == "connected" else "Saved"
        else:
            interaction = Interaction(
                user_id=user_id,
                target_user_id=action.target_user_id,
                interaction_type=action.interaction_type,
                notes=action.notes,
                status="Connected" if action.interaction_type == "connected" else "Saved"
            )
            db.add(interaction)
        db.commit()
        db.refresh(interaction)
        return interaction

    @staticmethod
    def remove(db: Session, user_id: int, target_user_id: int, interaction_type: str) -> bool:
        inter = db.query(Interaction).filter(
            Interaction.user_id == user_id,
            Interaction.target_user_id == target_user_id,
            Interaction.interaction_type == interaction_type
        ).first()
        if inter:
            db.delete(inter)
            db.commit()
            return True
        return False
