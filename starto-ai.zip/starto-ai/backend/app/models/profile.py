import enum
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Float, ForeignKey, JSON
from sqlalchemy.orm import relationship
from backend.app.database import Base


class Profile(Base):
    __tablename__ = "profiles"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    role = Column(String(50), nullable=False)
    company_or_firm_name = Column(String(255), nullable=True)
    tagline = Column(String(255), nullable=True)
    bio = Column(Text, nullable=True)
    website = Column(String(255), nullable=True)
    location = Column(String(100), nullable=True)
    industry = Column(String(100), nullable=True)  # e.g., AI/ML, FinTech, HealthTech, CleanTech, SaaS, EdTech
    stage = Column(String(50), nullable=True)  # Pre-Seed, Seed, Series A, Series B+, Growth
    ticket_size_min = Column(Float, default=0.0)
    ticket_size_max = Column(Float, default=0.0)
    traction_arr = Column(Float, default=0.0)  # Annual recurring revenue or equivalent
    skills_or_thesis = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    user = relationship("User", back_populates="profile")


class PitchDeck(Base):
    __tablename__ = "pitch_decks"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(255), nullable=False)
    filename = Column(String(255), nullable=True)
    problem = Column(Text, nullable=True)
    solution = Column(Text, nullable=True)
    market_size_tam = Column(String(100), nullable=True)
    business_model = Column(Text, nullable=True)
    target_raise = Column(Float, default=0.0)
    deck_status = Column(String(50), default="Parsed & Ready")  # Uploaded, Parsing, Parsed & Ready
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    user = relationship("User", back_populates="pitch_decks")


class Interaction(Base):
    __tablename__ = "interactions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    target_user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    interaction_type = Column(String(50), nullable=False)  # 'saved', 'connected', 'requested_intro', 'message'
    notes = Column(Text, nullable=True)
    status = Column(String(50), default="Pending")  # 'Pending', 'Connected', 'Accepted', 'Declined'
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    user = relationship("User", foreign_keys=[user_id])
    target_user = relationship("User", foreign_keys=[target_user_id])
