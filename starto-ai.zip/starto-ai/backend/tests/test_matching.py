from fastapi.testclient import TestClient
from backend.app.main import app

def test_matching_and_profiles(client: TestClient):
    # 1. Register a founder
    reg_payload = {
        "full_name": "Test Founder",
        "email": "matching_tester@example.com",
        "password": "Password123!",
        "role": "STARTUP"
    }
    reg_res = client.post("/auth/register", json=reg_payload)
    assert reg_res.status_code == 201
    token = reg_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # 2. Get and update profile
    get_prof = client.get("/api/v1/profile/me", headers=headers)
    assert get_prof.status_code == 200

    update_prof = client.put("/api/v1/profile/me", json={
        "company_or_firm_name": "DeepMind Runner",
        "industry": "AI/ML",
        "stage": "Seed",
        "ticket_size_min": 500000.0,
        "ticket_size_max": 2000000.0,
        "skills_or_thesis": "Autonomous agent infrastructure"
    }, headers=headers)
    assert update_prof.status_code == 200
    assert update_prof.json()["company_or_firm_name"] == "DeepMind Runner"

    # 3. Create pitch deck
    deck_res = client.post("/api/v1/pitch-decks", json={
        "title": "Agentic Platform Deck",
        "problem": "Manual coding is slow",
        "solution": "Autonomous coding assistants",
        "market_size_tam": "$50B",
        "business_model": "SaaS",
        "target_raise": 1500000.0
    }, headers=headers)
    assert deck_res.status_code == 201
    assert deck_res.json()["title"] == "Agentic Platform Deck"

    # 4. List pitch decks
    list_decks = client.get("/api/v1/pitch-decks", headers=headers)
    assert list_decks.status_code == 200
    assert len(list_decks.json()) >= 1

    # Register an Investor partner so matching has candidates
    client.post("/auth/register", json={
        "full_name": "Horizon Partner",
        "email": "horizon_test@example.com",
        "password": "Password123!",
        "role": "INVESTOR"
    })

    # 5. Get matches
    matches_res = client.get("/api/v1/matches", headers=headers)
    assert matches_res.status_code == 200
    matches = matches_res.json()
    assert isinstance(matches, list)
    assert len(matches) > 0
    top_match = matches[0]
    assert "explainability" in top_match
    assert top_match["explainability"]["overall_score"] > 0
    assert len(top_match["explainability"]["reasons"]) > 0

    # 6. Interact (save match)
    target_id = top_match["user_id"]
    inter_res = client.post("/api/v1/interactions", json={
        "target_user_id": target_id,
        "interaction_type": "saved",
        "notes": "Bookmarked for outreach"
    }, headers=headers)
    assert inter_res.status_code == 200

    # 7. Check interactions list
    list_inter = client.get("/api/v1/interactions", headers=headers)
    assert list_inter.status_code == 200
    assert len(list_inter.json()) >= 1
