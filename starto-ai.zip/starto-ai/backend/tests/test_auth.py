import pytest
from fastapi.testclient import TestClient
from backend.app.main import app

# Using client fixture from conftest.py


def test_user_registration_success(client):
    email = "testfounder_1@example.com"
    payload = {
        "full_name": "Test Founder",
        "email": email,
        "password": "strongPassword123",
        "role": "STARTUP"
    }
    response = client.post("/auth/register", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert "user" in data
    assert data["user"]["email"] == email
    assert data["user"]["full_name"] == "Test Founder"
    assert data["user"]["role"] == "STARTUP"


def test_user_registration_duplicate_fails(client):
    email = "testfounder_duplicate@example.com"
    payload = {
        "full_name": "Duplicate Test",
        "email": email,
        "password": "password123",
        "role": "STARTUP"
    }
    res1 = client.post("/auth/register", json=payload)
    assert res1.status_code == 201

    # Second registration with same email
    res2 = client.post("/auth/register", json=payload)
    assert res2.status_code == 400
    assert "already exists" in res2.text


def test_user_login_success(client):
    email = "login_test@example.com"
    reg_payload = {
        "full_name": "Login Tester",
        "email": email,
        "password": "validPassword456",
        "role": "INVESTOR"
    }
    res_reg = client.post("/auth/register", json=reg_payload)
    assert res_reg.status_code == 201

    login_payload = {
        "email": email,
        "password": "validPassword456"
    }
    res_login = client.post("/auth/login", json=login_payload)
    assert res_login.status_code == 200
    token_data = res_login.json()
    assert "access_token" in token_data
    assert token_data["token_type"] == "bearer"
    assert token_data["user"]["role"] == "INVESTOR"


def test_user_login_invalid_password(client):
    email = "wrong_pw@example.com"
    reg_payload = {
        "full_name": "Wrong PW Tester",
        "email": email,
        "password": "correctPassword",
        "role": "MENTOR"
    }
    client.post("/auth/register", json=reg_payload)

    login_payload = {
        "email": email,
        "password": "incorrectPassword"
    }
    res = client.post("/auth/login", json=login_payload)
    assert res.status_code == 401
    assert "Invalid email or password" in res.text


def test_auth_me_with_token(client):
    email = "auth_me@example.com"
    reg_payload = {
        "full_name": "Me Tester",
        "email": email,
        "password": "mySecurePassword123",
        "role": "ADMIN"
    }
    client.post("/auth/register", json=reg_payload)

    login_res = client.post("/auth/login", json={"email": email, "password": "mySecurePassword123"})
    token = login_res.json()["access_token"]

    me_res = client.get("/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me_res.status_code == 200
    assert me_res.json()["email"] == email
    assert me_res.json()["role"] == "ADMIN"
