import pytest
from sqlalchemy import text
from backend.app.database import engine, check_database_connection, SessionLocal


def test_database_connection():
    db_status = check_database_connection()
    assert db_status["status"] == "healthy"
    assert "dialect" in db_status


def test_session_execution():
    db = SessionLocal()
    try:
        result = db.execute(text("SELECT 1 AS alive")).scalar()
        assert result == 1
    finally:
        db.close()
