import pytest
from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["service"] == "Starto AI"
    assert "status" in data
    assert "database" in data
    assert data["database"]["status"] == "healthy"


def test_system_info_endpoint():
    response = client.get("/api/v1/info")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Starto AI"
    assert "matching_pipeline" in data
    assert len(data["matching_pipeline"]) >= 5


def test_root_serves_landing_or_status():
    response = client.get("/")
    assert response.status_code == 200
    assert ("Starto AI" in response.text) or ("Starto" in response.text)
